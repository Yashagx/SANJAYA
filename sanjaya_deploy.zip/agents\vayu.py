import requests
import os
from dotenv import load_dotenv
load_dotenv()

def get_weather_risk(location: str) -> dict:
    api_key = os.getenv("OPENWEATHER_API_KEY")
    
    # Gulf/Hormuz special case
    if any(x in location.lower() for x in ["hormuz", "gulf", "khor fakkan", "dubai", "muscat"]):
        base_risk = 0.45
    else:
        base_risk = 0.0

    try:
        resp = requests.get(
            "https://api.openweathermap.org/data/2.5/weather",
            params={"q": location, "appid": api_key, "units": "metric"},
            timeout=5
        )
        data = resp.json()

        if resp.status_code != 200:
            # Location not found - use base risk
            return {
                "score": round(base_risk, 3),
                "condition": "Unknown (API fallback)",
                "wind_speed": 0,
                "location_queried": location
            }

        wind_speed = data.get("wind", {}).get("speed", 0)
        weather_id = data.get("weather", [{}])[0].get("id", 800)
        condition = data.get("weather", [{}])[0].get("description", "clear")

        # Score based on conditions
        wind_score = min(wind_speed / 25.0, 1.0)

        # Severe weather codes
        if weather_id < 300:      # Thunderstorm
            severity = 0.9
        elif weather_id < 400:    # Drizzle
            severity = 0.3
        elif weather_id < 600:    # Rain
            severity = 0.5
        elif weather_id < 700:    # Snow
            severity = 0.7
        elif weather_id < 800:    # Atmosphere (fog, dust)
            severity = 0.6
        else:                     # Clear/clouds
            severity = 0.1

        score = max(base_risk, round((wind_score * 0.4) + (severity * 0.6), 3))

        return {
            "score": score,
            "condition": condition,
            "wind_speed": wind_speed,
            "location_queried": location
        }

    except Exception as e:
        return {
            "score": round(base_risk, 3),
            "condition": f"API error: {str(e)}",
            "wind_speed": 0,
            "location_queried": location
        }
