"""
NIDHI — ML Model Agent
Loads the trained XGBoost model and returns delay probability
along with SHAP-based feature explanations.
"""

import os
import json
import numpy as np
import joblib
import shap

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "model", "sanjaya_model.pkl")
FEATURES_PATH = os.path.join(BASE_DIR, "model", "features.json")

# Shipping mode encoding (must match train.py)
SHIPPING_MODE_MAP = {
    "Standard Class": 0,
    "Second Class": 1,
    "First Class": 2,
    "Same Day": 3,
}

# Lazy-loaded globals
_model = None
_feature_list = None
_explainer = None


def _load_model():
    """Load model and feature list once, then cache."""
    global _model, _feature_list, _explainer
    if _model is None:
        _model = joblib.load(MODEL_PATH)
        with open(FEATURES_PATH, "r") as f:
            _feature_list = json.load(f)
        _explainer = shap.TreeExplainer(_model)
    return _model, _feature_list, _explainer


def get_delay_probability(features: dict) -> tuple:
    """
    Run XGBoost inference and return delay probability + SHAP values.

    Parameters
    ----------
    features : dict
        Must contain keys matching the trained feature list:
        - days_real, days_scheduled, benefit, sales, quantity,
          discount_rate, profit_ratio, category_id, transport_mode, month

    Returns
    -------
    tuple[float, list]
        (probability_of_delay, shap_values_list)
    """
    model, feature_list, explainer = _load_model()

    # Build row in exact feature_list order using trained column names
    row = [features.get(f, 0) for f in feature_list]

    X = np.array([row])
    p_delay = float(model.predict_proba(X)[0][1])

    shap_values = explainer.shap_values(X)
    # shap_values may be a list (for binary) or ndarray
    if isinstance(shap_values, list):
        sv = shap_values[1][0].tolist()
    else:
        sv = shap_values[0].tolist()

    return (round(p_delay, 4), sv)
