import json
from agents.vayu import get_weather_risk
from agents.sanchar import get_geo_risk
from agents.nidhi import get_delay_probability
from agents.darpana import get_port_risk
from agents.viveka import get_customs_risk

def orchestrate(payload: dict) -> dict:
    origin = payload.get("origin", "")
    destination = payload.get("destination", "")

    print(f"[ARJUNA] Orchestrating risk for {origin} -> {destination}")

    # Fire all agents
    print("[ARJUNA] Calling Vayu (weather)...")
    weather = get_weather_risk(origin)
    s_weather = weather["score"]

    print("[ARJUNA] Calling Sanchar (geopolitics)...")
    geo = get_geo_risk(origin, destination)
    s_geo = geo["score"]

    print("[ARJUNA] Calling Nidhi (ML model)...")
    features = {
        "Days for shipping (real)": payload.get("days_real", 5),
        "Days for shipment (scheduled)": payload.get("days_scheduled", 3),
        "Benefit per order": payload.get("benefit_per_order", 50),
        "Sales per customer": payload.get("sales_per_customer", 200),
        "Order Item Discount Rate": payload.get("discount_rate", 0.1),
        "Order Item Profit Ratio": payload.get("profit_ratio", 0.05),
        "Order Item Quantity": payload.get("quantity", 10),
        "Category Id": payload.get("category_id", 73),
        "Shipping_Mode_Encoded": payload.get("shipping_mode_encoded", 0),
        "Order_Month": payload.get("month", 2)
    }
    p_delay, shap_values = get_delay_probability(features)

    print("[ARJUNA] Calling Darpana (port)...")
    c_port = get_port_risk(origin)

    print("[ARJUNA] Calling Viveka (customs)...")
    customs_risk = get_customs_risk(
        payload.get("hs_code", "8471"),
        origin
    )

    # Composite RS formula
    rs = (0.40 * p_delay) + (0.25 * s_weather) + (0.20 * s_geo) + (0.15 * c_port)
    rs_score = round(rs * 100, 1)

    # Risk level
    if rs_score >= 75:
        risk_level = "CRITICAL"
        recommendation = "REROUTE via Cape of Good Hope -- same decision as Maersk/MSC/Hapag-Lloyd"
        color = "RED"
    elif rs_score >= 50:
        risk_level = "MEDIUM"
        recommendation = "MONITOR closely -- prepare contingency rerouting plan"
        color = "AMBER"
    else:
        risk_level = "LOW"
        recommendation = "PROCEED -- no significant risk detected"
        color = "GREEN"

    result = {
        "vessel_id": payload.get("vessel_id", "UNKNOWN"),
        "route": f"{origin} -> {destination}",
        "risk_score": rs_score,
        "risk_level": risk_level,
        "color": color,
        "recommendation": recommendation,
        "breakdown": {
            "p_delay": round(p_delay, 4),
            "s_weather": round(s_weather, 4),
            "s_geo": round(s_geo, 4),
            "c_port": round(c_port, 4),
            "customs_risk": round(customs_risk, 4)
        },
        "evidence": {
            "weather": weather,
            "geopolitics": geo
        },
        "shap_top5": shap_values[:5] if shap_values else [],
        "rerouting_options": [
            {
                "route": "Continue via Strait of Hormuz",
                "extra_days": 0,
                "on_time_probability": "3%",
                "extra_cost": "$1,000,000+",
                "verdict": "DO NOT PROCEED"
            },
            {
                "route": "Reroute via Cape of Good Hope",
                "extra_days": 13,
                "on_time_probability": "94%",
                "extra_cost": "$180,000",
                "verdict": "RECOMMENDED"
            },
            {
                "route": "Reroute via Suez / Red Sea",
                "extra_days": 3,
                "on_time_probability": "45%",
                "extra_cost": "$60,000",
                "verdict": "NOT ADVISED - Houthi risk"
            }
        ]
    }

    print(f"[ARJUNA] COMPOSITE RS = {rs_score} / {risk_level}")
    return result
