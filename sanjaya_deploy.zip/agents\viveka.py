"""
VIVEKA — Customs & Regulatory Risk Agent
Returns a risk score based on HS code and origin country.
"""


def get_customs_risk(hs_code: str, origin: str) -> float:
    """
    Compute customs / regulatory risk.

    Parameters
    ----------
    hs_code : str
        Harmonised System code for the goods.
    origin : str
        Country or region of origin.

    Returns
    -------
    float
        Risk score between 0.0 and 1.0.
    """
    # TODO: integrate ICEGATE API
    return 0.3
