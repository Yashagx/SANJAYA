import requests
import os
from dotenv import load_dotenv
load_dotenv()

def get_geo_risk(origin: str, destination: str) -> dict:
    api_key = os.getenv("NEWSCATCHER_API_KEY")

    # Known crisis zones - hardcoded override
    crisis_zones = {
        "hormuz": 0.99, "iran": 0.95, "strait": 0.99,
        "khor fakkan": 0.99, "red sea": 0.85, "houthi": 0.85,
        "ukraine": 0.80, "taiwan": 0.70, "south china sea": 0.75
    }

    combined = f"{origin} {destination}".lower()
    for zone, score in crisis_zones.items():
        if zone in combined:
            return {
                "score": score,
                "total_hits": 999,
                "top_headline": f"Active crisis zone detected: {zone}",
                "query_used": combined
            }

    # Live news query
    query = f"{origin} {destination} conflict strike sanction port delay"
    try:
        resp = requests.get(
            "https://v3-api.newscatcherapi.com/api/search",
            headers={"x-api-token": api_key},
            params={
                "q": query,
                "lang": "en",
                "page_size": 10,
                "sort_by": "relevancy"
            },
            timeout=8
        )
        data = resp.json()

        if resp.status_code != 200:
            return {
                "score": 0.2,
                "total_hits": 0,
                "top_headline": "API unavailable",
                "query_used": query
            }

        total = data.get("total_hits", 0)
        articles = data.get("articles", [])
        top_headline = articles[0].get("title", "No headline") if articles else "No news found"

        # Normalise: 0 hits = 0.1, 50+ hits = 0.9
        score = min(0.1 + (total / 55.0) * 0.8, 0.95)

        return {
            "score": round(score, 3),
            "total_hits": total,
            "top_headline": top_headline,
            "query_used": query
        }

    except Exception as e:
        return {
            "score": 0.2,
            "total_hits": 0,
            "top_headline": f"Error: {str(e)}",
            "query_used": query
        }
