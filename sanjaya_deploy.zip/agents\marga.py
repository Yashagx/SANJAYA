"""
MARGA — Road / Surface Transport Risk Agent
Returns a risk score for the road/land segment of the shipment.
"""


def get_road_risk(route: str) -> float:
    """
    Compute road transport risk for the given route.

    Parameters
    ----------
    route : str
        Route description (e.g. "NH-48 Mumbai–Delhi").

    Returns
    -------
    float
        Risk score between 0.0 and 1.0.
    """
    # TODO: integrate ULIP FASTag API
    return 0.4
