"""
DARPANA — Port / Maritime Risk Agent
Returns a risk score for the origin port or maritime route.
"""


def get_port_risk(origin: str) -> float:
    """
    Compute port / maritime risk based on the origin.

    Parameters
    ----------
    origin : str
        Shipment origin location or port name.

    Returns
    -------
    float
        Risk score between 0.0 and 1.0.
    """
    # TODO: replace with live AIS API call
    origin_lower = origin.lower()
    if any(x in origin_lower for x in ["hormuz", "khor fakkan", "bandar abbas", "fujairah"]):
        return 0.98
    if any(x in origin_lower for x in ["gulf", "dubai", "muscat", "doha"]):
        return 0.75
    return 0.35
