"""
SANJAYA — Multi-Agent Shipment Risk Intelligence System
FastAPI backend serving risk assessments.
"""

from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional

from agents.arjuna import orchestrate

app = FastAPI(
    title="SANJAYA",
    description="Multi-Agent Shipment Risk Intelligence System",
    version="1.0.0",
)


# ── Request schema ──────────────────────────────────────────────────────
class PredictRequest(BaseModel):
    origin: str
    destination: str
    vessel_id: Optional[str] = "N/A"
    transport_mode: Optional[str] = "Standard Class"
    days_real: Optional[int] = 5
    days_scheduled: Optional[int] = 4
    month: Optional[int] = 1
    category_id: Optional[int] = 1
    hs_code: Optional[str] = "0000"
    benefit: Optional[float] = 50.0
    sales: Optional[float] = 200.0
    quantity: Optional[int] = 2
    discount_rate: Optional[float] = 0.05
    profit_ratio: Optional[float] = 0.1


# ── Endpoints ───────────────────────────────────────────────────────────
@app.get("/health")
def health_check():
    """Health-check endpoint."""
    return {"status": "ok", "system": "SANJAYA"}


@app.post("/predict")
def predict(req: PredictRequest):
    """Run the full SANJAYA risk assessment pipeline."""
    payload = req.model_dump()
    result = orchestrate(payload)
    return result


# ── Entrypoint ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
